# """ Guessing Game """
import random
#
#
def guessing_game(target: int) -> int:
    answer = random.randint(1, 1000)  # generate a random integer from 1 to 1000
    # your code goes here.
    print(f"answer: {answer}")

    min = 1
    max = 1000
    steps = 0

    while target != answer:
        steps += 1

        if target < answer:
            print(f"Wrong! Guess count: {steps}")
            min = target + 1
            target = int(input(f"Enter your guess from {min} to {max}: "))
        else:
            print(f"Wrong! Guess count: {steps}")
            max = target - 1
            target = int(input(f"Enter your guess from {min} to {max}: "))

    print(f"You got it! The hidden number is {answer}\n It took you {steps + 1} guess(es)")

# https://stackoverflow.com/questions/419163/what-does-if-name-main-do

if __name__ == '__main__':
    target = int(input(f"Enter your guess from 1 to 1000: "))
    guessing_game(target)
